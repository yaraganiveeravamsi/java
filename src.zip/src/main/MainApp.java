public class MainApp
{
    public static void main(String[] args) 
    {
        AppLogger Logger = new AppLogger();
        // call the overridden logInfo() method
        Logger.logInfo();
        // call the static logError() method from the Logger interface
        Logger.logError();


    }
}
