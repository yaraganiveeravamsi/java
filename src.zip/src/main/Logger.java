public interface Logger {
    //Default method
    default void logInfo()
    {
        System.out.println("Default logInfo() from Logger interface");
    }
    //Static method
    default void logError()
    {
        System.out.println("Static logError() from Logger interface");
    }
}