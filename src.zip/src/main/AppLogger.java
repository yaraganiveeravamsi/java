public class AppLogger implements Logger
{
    @Override
    public void logInfo() 
    {
        System.out.println("Overridden logInfo() from AppLogger class");
    }
    @Override
    public void logError() 
    {
        System.out.println("Overridden logError() from AppLogger class");
    }
}