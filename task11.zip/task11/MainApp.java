public class MainApp 
{
    public static void main(String[] args) 
    {
      
        MathOperation addition = (a, b) -> a + b;

        
        MathOperation subtraction = (a, b) -> a - b;

        
        MathOperation multiplication = (a, b) -> a * b;

        // Calling each lambda
        System.out.println("Addition: " + addition.operate(5, 3));  
        System.out.println("Subtraction: " + subtraction.operate(5, 3));   
        System.out.println("Multiplication: " + multiplication.operate(5, 3)); 
    }
}
